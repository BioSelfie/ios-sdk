//
//  BioSelfie.h
//  BioSelfie
//
//  Created by Febin Fathah on 28/09/2022.
//

#include <Foundation/Foundation.h>
#include "shim.h"
#import "ICAIDCardUtil.h"
#import <BioSelfie/FLAnimatedImageView.h>
#import <BioSelfie/FLAnimatedImage.h>

//! Project version number for BioSelfie.
FOUNDATION_EXPORT double BioSelfieVersionNumber;

//! Project version string for BioSelfie.
FOUNDATION_EXPORT const unsigned char BioSelfieVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BioSelfie/PublicHeader.h>

