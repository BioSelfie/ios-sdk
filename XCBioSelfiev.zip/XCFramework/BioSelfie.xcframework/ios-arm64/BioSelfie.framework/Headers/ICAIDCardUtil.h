//
//  ICAIDCardUtil.h
//  BioSelfie
//
//  Created by Febin Fathah on 20/12/2022.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ICAIDCardUtil : NSObject


/// Generate a secure key for request
+(NSString*)generateSecureKey;

@end

NS_ASSUME_NONNULL_END
